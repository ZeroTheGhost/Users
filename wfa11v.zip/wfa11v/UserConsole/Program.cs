﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using ClassLibrary2;
namespace UserConsole {
    internal class Program {
        static User user { get; set; }
        static void Main(string[] args) {
            Login();
        }
        public static void Login() {
            string json = File.ReadAllText("C:\\Users\\Student\\source\\wfa11v\\WindowsFormsApp2\\bin\\Debug\\json.txt");
            User[] users = JsonSerializer.Deserialize(json, typeof(User[])) as User[];
            user = new User();
            string command = "";
            while (command.ToLower() != "end") {
                Console.Write(user.Username + ">");
                command = Console.ReadLine();
                if (command == "login") {
                    Console.Write("username: ");
                    command = Console.ReadLine();
                    for (int i = 0; i < users.Count(); i++) {
                        if (command == users[i].Username) {
                            Console.Write("password: ");
                            command = ReadPassword();
                            if (command == users[i].Password) {
                                user = users[i];
                            }
                            else {
                                Console.WriteLine("Wrong password!");
                            }
                        }
                        else {
                            Console.WriteLine("Wrong username!");
                        }
                    }
                }
            }
        }
       public static string ReadPassword()
        {
            string password = "";
            ConsoleKeyInfo info = Console.ReadKey(true);
            while (info.Key != ConsoleKey.Enter)
            {
                if (info.Key != ConsoleKey.Backspace)
                {
                    Console.Write("*");
                    password += info.KeyChar;
                }
                else if (info.Key == ConsoleKey.Backspace)
                {
                    if (!string.IsNullOrEmpty(password))
                     password = password.Substring(0, password.Length - 1);
                }
                info = Console.ReadKey(true);
            }
            Console.WriteLine();
            return password;
        }
    }
}
