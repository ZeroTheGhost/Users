﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary2;
namespace WindowsFormsApp1 {
    public partial class Form1 : Form {
        List<Circle> circles;
        
        public Form1() {
            InitializeComponent();
            circles  = new List<Circle>();
            
        }
        
        private void button1_Click(object sender, EventArgs e) {
            Circle circle = new Circle();
            circle.R = int.Parse(textBox1.Text);
            circles.Add(circle);
            //listBox1.Items.Add(circles);
            button2_Click(sender, e);
        }

        private void textBox1_TextChanged(object sender, EventArgs e) {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e) {

        }

        private void button2_Click(object sender, EventArgs e) {
            textBox2.Clear();
            for (int i = 0; i < circles.Count; i++) {
                circles[i].Id = i;
                textBox2.AppendText(Convert.ToString(circles[i]));
            }
            
        }

        private void Form1_Load(object sender, EventArgs e) {
            
        }

        private void button3_Click(object sender, EventArgs e) {
            for (int i = 0; i < circles.Count; i++) {
                if (textBox1.Text == Convert.ToString(circles[i].Id)) {
                    circles.Remove(circles[i]);
                }
            }
            button2_Click(sender, e);
        }

        private void button4_Click(object sender, EventArgs e) {
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) {

        }

        private void button7_Click(object sender, EventArgs e) {
            string json;
            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
            };
            json = JsonSerializer.Serialize(textBox2.Text, options);
            File.WriteAllText("test.txt", json);
        }
    }
}
