﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2 {
    public class User {
        public string Username { get; set; }
        public string Password { get; set; }
        public int UserID { get; set; }
        public int GroupID { get; set; }
        public string UserIDInfo { get; set; }
        public string HomeDirectory { get; set; }
        public string CommandShell { get; set; }
        public override string ToString() {
            return Username;
        }
    }
}
