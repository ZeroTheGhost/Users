﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary2
{
    public class Circle
    {
        public int Id { get; set; }
        public int R { get; set; }
        public double Area {
            get {
                return Math.Round(Math.PI * R * R, 2);
            }
        }
        public override string ToString() {
            return R + " | " + Area + "  ";
        }
    }
}
